This is a basic resume/ portfolio site.  I haven't focued on design to much but hope to pretty it up soon.

